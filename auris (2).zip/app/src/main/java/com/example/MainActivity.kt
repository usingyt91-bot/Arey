package com.example

import android.Manifest
import android.content.ContentUris
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.support.v4.media.MediaMetadataCompat
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.os.SystemClock
import androidx.palette.graphics.Palette
import androidx.core.app.NotificationCompat
import android.media.PlaybackParams
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.SessionManager
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.MediaTrack
import com.google.android.gms.common.images.WebImage
import androidx.mediarouter.media.MediaRouter
import androidx.mediarouter.media.MediaRouteSelector
import com.google.android.gms.cast.CastMediaControlIntent
import java.net.NetworkInterface
import java.util.Collections
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.json.JSONArray
import java.net.URLEncoder
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearOutSlowInEasing
import com.example.ui.theme.MyApplicationTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: AurisViewModel = viewModel()
            val dominantColorInt by viewModel.dominantColor.collectAsState()
            val dominantColor = dominantColorInt?.let { Color(it) }

            MyApplicationTheme(dynamicColor = dominantColor) {
                AurisApp(viewModel = viewModel)
            }
        }
    }
}

data class AudioTrack(
    val id: Long,
    val title: String,
    val artist: String,
    val duration: Long,
    val albumId: Long,
    val uri: Uri,
    val albumArtUri: Uri,
    val folderName: String,
    val album: String
)

data class LyricLine(val timeMs: Long, val text: String)

data class CastDevice(val name: String, val ipAddress: String, val port: Int)

fun parseLrc(content: String): List<LyricLine> {
    val lines = content.split("\n")
    val regex = Regex("\\[(\\d{2,}):(\\d{2})\\.(\\d{2,3})\\](.*)")
    val result = mutableListOf<LyricLine>()
    for (line in lines) {
        val match = regex.find(line)
        if (match != null) {
            val min = match.groupValues[1].toLong()
            val sec = match.groupValues[2].toLong()
            val msStr = match.groupValues[3]
            val ms = if (msStr.length == 2) msStr.toLong() * 10 else msStr.toLong()
            val text = match.groupValues[4].trim()
            if (text.isNotEmpty()) {
                val timeMs = min * 60000 + sec * 1000 + ms
                result.add(LyricLine(timeMs, text))
            }
        }
    }
    return result.sortedBy { it.timeMs }
}

class AurisViewModel(application: android.app.Application) : androidx.lifecycle.AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("auris_prefs", android.content.Context.MODE_PRIVATE)
    
    private var mediaPlayer: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    private val _tracks = MutableStateFlow<List<AudioTrack>>(emptyList())
    val tracks = _tracks.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _filteredTracks = MutableStateFlow<List<AudioTrack>>(emptyList())
    val filteredTracks = _filteredTracks.asStateFlow()

    private val _currentTrack = MutableStateFlow<AudioTrack?>(null)
    val currentTrack = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    private val _isShuffleEnabled = MutableStateFlow(false)
    val isShuffleEnabled = _isShuffleEnabled.asStateFlow()

    private val _isLoopEnabled = MutableStateFlow(false)
    val isLoopEnabled = _isLoopEnabled.asStateFlow()

    private val _progress = MutableStateFlow(0f)
    val progress = _progress.asStateFlow()
    
    private val _currentTimeMs = MutableStateFlow(0L)
    val currentTimeMs = _currentTimeMs.asStateFlow()

    // Volume and Balance
    private val _volume = MutableStateFlow(1f)
    val volume = _volume.asStateFlow()

    private val _balance = MutableStateFlow(0f) // -1.0 (Left) to 1.0 (Right)
    val balance = _balance.asStateFlow()

    // Effects

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed = _playbackSpeed.asStateFlow()

    private val _bassBoostLevel = MutableStateFlow(0f)
    val bassBoostLevel = _bassBoostLevel.asStateFlow()

    private val _eqLevels = MutableStateFlow(MutableList(5) { 0f })
    val eqLevels = _eqLevels.asStateFlow()

    private var minEqLevel: Short = 0
    private var maxEqLevel: Short = 0

    private val _likedTracks = MutableStateFlow<Set<Long>>(emptySet())
    val likedTracks = _likedTracks.asStateFlow()

    private val _playlists = MutableStateFlow<Map<String, List<Long>>>(emptyMap())
    val playlists = _playlists.asStateFlow()

    private val _playbackQueue = MutableStateFlow<List<AudioTrack>>(emptyList())
    val playbackQueue = _playbackQueue.asStateFlow()

    private val _castingTvName = MutableStateFlow<String?>(null)
    val castingTvName = _castingTvName.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<CastDevice>>(emptyList())
    val discoveredDevices = _discoveredDevices.asStateFlow()

    private val _isSearchingDevices = MutableStateFlow(false)
    val isSearchingDevices = _isSearchingDevices.asStateFlow()

    private var nsdManager: NsdManager? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    private var localHttpServer: LocalHttpServer? = null
    private var castContext: CastContext? = null
    private var castSession: CastSession? = null
    private var mediaRouterCallback: MediaRouter.Callback? = null

    private val sessionManagerListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) {
            castSession = session
            _castingTvName.value = session.castDevice?.friendlyName ?: "Google TV"
            startLocalServer()
            updatePlayerVolume()
            streamCurrentSongToTv()
        }

        override fun onSessionEnded(session: CastSession, error: Int) {
            castSession = null
            _castingTvName.value = null
            stopLocalServer()
            updatePlayerVolume()
        }

        override fun onSessionStarting(session: CastSession) {}
        override fun onSessionStartFailed(session: CastSession, error: Int) {}
        override fun onSessionEnding(session: CastSession) {}
        override fun onSessionResuming(session: CastSession, sessionId: String) {}
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            castSession = session
            _castingTvName.value = session.castDevice?.friendlyName ?: "Google TV"
            startLocalServer()
            updatePlayerVolume()
            streamCurrentSongToTv()
        }
        override fun onSessionResumeFailed(session: CastSession, error: Int) {}
        override fun onSessionSuspended(session: CastSession, reason: Int) {}
    }

    private fun escapeJson(value: String): String {
        return value.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
    }

    private fun getPlaybackStateJson(): String {
        val track = _currentTrack.value
        return if (track != null) {
            val trackId = track.id
            val title = escapeJson(track.title)
            val artist = escapeJson(track.artist)
            val album = escapeJson(track.album ?: "")
            val albumArtUri = track.albumArtUri.toString()
            val isPlaying = _isPlaying.value
            val positionMs = _currentTimeMs.value
            val durationMs = track.duration
            """
            {
                "trackId": $trackId,
                "title": "$title",
                "artist": "$artist",
                "album": "$album",
                "albumArtUri": "$albumArtUri",
                "isPlaying": $isPlaying,
                "positionMs": $positionMs,
                "durationMs": $durationMs
            }
            """.trimIndent()
        } else {
            """
            {
                "trackId": 0,
                "title": "No Track",
                "artist": "No Artist",
                "album": "",
                "albumArtUri": "",
                "isPlaying": false,
                "positionMs": 0,
                "durationMs": 0
            }
            """.trimIndent()
        }
    }

    fun broadcastStateToTv() {
        val server = localHttpServer ?: return
        server.broadcastState(getPlaybackStateJson())
    }

    fun sendUrlToTv(url: String) {
        val session = castSession ?: return
        val namespace = "urn:x-cast:com.whizzosoftware.dashcast"
        val payload = "{\"url\":\"$url\",\"force\":true,\"reload\":true}"
        try {
            session.sendMessage(namespace, payload)
                ?.setResultCallback { status ->
                    if (!status.isSuccess) {
                        android.util.Log.e("Auris", "Failed to send DashCast load message: ${status.statusMessage}")
                    }
                }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startLocalServer() {
        if (localHttpServer != null) return
        val context = getApplication<android.app.Application>()
        localHttpServer = LocalHttpServer(
            context = context,
            port = 8085,
            getAudioUri = { id ->
                _tracks.value.find { it.id == id }?.uri
            },
            getLyricsContent = { id ->
                prefs.getString("lyrics_$id", "") ?: ""
            },
            getAlbumArtUri = { id ->
                _tracks.value.find { it.id == id }?.albumArtUri
            },
            getCurrentState = {
                getPlaybackStateJson()
            }
        ).apply {
            start()
        }
    }

    private fun stopLocalServer() {
        localHttpServer?.stop()
        localHttpServer = null
    }

    fun startCasting(tvName: String) {
        val context = getApplication<android.app.Application>()
        val mediaRouter = MediaRouter.getInstance(context)
        val route = mediaRouter.routes.find { it.name == tvName || it.id.contains(tvName) }
        if (route != null) {
            mediaRouter.selectRoute(route)
        } else {
            _castingTvName.value = tvName
            startLocalServer()
            streamCurrentSongToTv()
        }
    }

    fun stopCasting() {
        val context = getApplication<android.app.Application>()
        try {
            val mediaRouter = MediaRouter.getInstance(context)
            mediaRouter.selectRoute(mediaRouter.defaultRoute)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        castSession = null
        _castingTvName.value = null
        stopLocalServer()
    }

    @Synchronized
    private fun addDiscoveredDevice(device: CastDevice) {
        val currentList = _discoveredDevices.value
        if (currentList.none { it.name == device.name || it.ipAddress == device.ipAddress }) {
            _discoveredDevices.value = currentList + device
        }
    }

    fun startDiscovery() {
        val context = getApplication<android.app.Application>()
        try {
            val wifiManager = context.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            multicastLock = wifiManager?.createMulticastLock("AurisCastLock")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        _discoveredDevices.value = emptyList()
        _isSearchingDevices.value = true

        try {
            val mediaRouter = MediaRouter.getInstance(context)
            val selector = MediaRouteSelector.Builder()
                .addControlCategory(CastMediaControlIntent.categoryForCast(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID))
                .build()
            
            mediaRouterCallback = object : MediaRouter.Callback() {
                override fun onRouteAdded(router: MediaRouter, route: MediaRouter.RouteInfo) {
                    addDiscoveredDevice(CastDevice(route.name, "Cast Route", 8009))
                }
                override fun onRouteRemoved(router: MediaRouter, route: MediaRouter.RouteInfo) {
                    _discoveredDevices.value = _discoveredDevices.value.filterNot { it.name == route.name }
                }
            }
            mediaRouter.addCallback(selector, mediaRouterCallback!!, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val manager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return
        nsdManager = manager

        val listener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {
                _isSearchingDevices.value = false
                stopDiscovery()
            }

            override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {
                _isSearchingDevices.value = false
            }

            override fun onDiscoveryStarted(serviceType: String?) {
                _isSearchingDevices.value = true
            }

            override fun onDiscoveryStopped(serviceType: String?) {
                _isSearchingDevices.value = false
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                try {
                    manager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {
                            val name = serviceInfo?.serviceName ?: "Google TV Device"
                            addDiscoveredDevice(CastDevice(name, "Unknown IP", 8009))
                        }

                        override fun onServiceResolved(resolvedInfo: NsdServiceInfo?) {
                            if (resolvedInfo == null) return
                            val host = resolvedInfo.host?.hostAddress ?: "Unknown IP"
                            val port = resolvedInfo.port
                            val name = resolvedInfo.serviceName
                            addDiscoveredDevice(CastDevice(name, host, port))
                        }
                    })
                } catch (e: Exception) {
                    val name = serviceInfo.serviceName
                    addDiscoveredDevice(CastDevice(name, "Unknown IP", 8009))
                }
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                val name = serviceInfo.serviceName
                _discoveredDevices.value = _discoveredDevices.value.filterNot { it.name == name }
            }
        }

        discoveryListener = listener
        try {
            manager.discoverServices("_googlecast._tcp", NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Exception) {
            e.printStackTrace()
            _isSearchingDevices.value = false
        }
    }

    fun stopDiscovery() {
        val context = getApplication<android.app.Application>()
        try {
            if (mediaRouterCallback != null) {
                MediaRouter.getInstance(context).removeCallback(mediaRouterCallback!!)
                mediaRouterCallback = null
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            if (nsdManager != null && discoveryListener != null) {
                nsdManager?.stopServiceDiscovery(discoveryListener)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        discoveryListener = null
        nsdManager = null

        try {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        multicastLock = null
        _isSearchingDevices.value = false
    }

    fun getLocalIpAddress(): String? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress) {
                        val sAddr = addr.hostAddress
                        val isIPv4 = sAddr.indexOf(':') < 0
                        if (isIPv4) return sAddr
                    }
                }
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
        return null
    }

    fun streamCurrentSongToTv() {
        val session = castSession ?: return
        val ip = getLocalIpAddress() ?: "127.0.0.1"
        val tvUrl = "http://$ip:8085/tv"
        
        sendUrlToTv(tvUrl)
        
        broadcastStateToTv()
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            broadcastStateToTv()
        }, 1500)
    }

    fun syncPlaybackStateToTv() {
        broadcastStateToTv()
    }

    private fun savePlaylists() {
        val editor = prefs.edit()
        editor.putStringSet("playlist_names", _playlists.value.keys)
        _playlists.value.forEach { (name, list) ->
            editor.putString("playlist_$name", list.joinToString(","))
        }
        val names = prefs.getStringSet("playlist_names", emptySet()) ?: emptySet()
        names.forEach { name ->
            if (!_playlists.value.containsKey(name)) {
                editor.remove("playlist_$name")
            }
        }
        editor.apply()
    }

    private fun loadPlaylists() {
        val names = prefs.getStringSet("playlist_names", emptySet()) ?: emptySet()
        val loadedPlaylists = mutableMapOf<String, List<Long>>()
        names.forEach { name ->
            val idsStr = prefs.getString("playlist_$name", "") ?: ""
            val ids = if (idsStr.isEmpty()) emptyList() else idsStr.split(",").mapNotNull { it.toLongOrNull() }
            loadedPlaylists[name] = ids
        }
        _playlists.value = loadedPlaylists
    }

    private fun saveLikedTracks() {
        prefs.edit().putString("liked_tracks", _likedTracks.value.joinToString(",")).apply()
    }

    private fun loadLikedTracks() {
        val likedStrs = prefs.getString("liked_tracks", "") ?: ""
        _likedTracks.value = if (likedStrs.isEmpty()) emptySet() else likedStrs.split(",").mapNotNull { it.toLongOrNull() }.toSet()
    }

    private fun savePlayHistory() {
        prefs.edit().putString("play_history", _playHistory.value.map { it.id }.joinToString(",")).apply()
    }

    fun createPlaylist(name: String) {
        if (!_playlists.value.containsKey(name) && name.isNotBlank()) {
            val newMap = _playlists.value.toMutableMap()
            newMap[name] = emptyList()
            _playlists.value = newMap
            savePlaylists()
        }
    }

    fun deletePlaylist(name: String) {
        val newMap = _playlists.value.toMutableMap()
        newMap.remove(name)
        _playlists.value = newMap
        savePlaylists()
    }

    fun addTrackToPlaylist(playlistName: String, trackId: Long) {
        val newMap = _playlists.value.toMutableMap()
        val list = newMap[playlistName]?.toMutableList() ?: mutableListOf()
        if (!list.contains(trackId)) {
            list.add(trackId)
            newMap[playlistName] = list
            _playlists.value = newMap
            savePlaylists()
        }
    }

    fun removeTrackFromPlaylist(playlistName: String, trackId: Long) {
        val newMap = _playlists.value.toMutableMap()
        val list = newMap[playlistName]?.toMutableList()
        if (list != null) {
            list.remove(trackId)
            newMap[playlistName] = list
            _playlists.value = newMap
            savePlaylists()
        }
    }

    fun addTrackToQueue(track: AudioTrack) {
        val currentQueue = if (_playbackQueue.value.isEmpty()) _filteredTracks.value.toMutableList() else _playbackQueue.value.toMutableList()
        if (!currentQueue.contains(track)) {
            currentQueue.add(track)
        }
        _playbackQueue.value = currentQueue
    }

    fun playNextInQueue(track: AudioTrack) {
        val currentQueue = if (_playbackQueue.value.isEmpty()) _filteredTracks.value.toMutableList() else _playbackQueue.value.toMutableList()
        val currentTrackIdx = currentQueue.indexOf(_currentTrack.value)
        if (currentTrackIdx != -1) {
            if (currentQueue.contains(track)) currentQueue.remove(track)
            currentQueue.add(currentTrackIdx + 1, track)
        } else {
            if (!currentQueue.contains(track)) currentQueue.add(0, track)
        }
        _playbackQueue.value = currentQueue
    }

    fun removeFromQueue(track: AudioTrack) {
        val currentQueue = _playbackQueue.value.toMutableList()
        currentQueue.remove(track)
        _playbackQueue.value = currentQueue
    }

    fun playTrackFromContext(track: AudioTrack, contextList: List<AudioTrack>, context: Context) {
        if (_playbackQueue.value != contextList) {
            _playbackQueue.value = contextList
        }
        playTrack(track, context)
    }

    fun toggleLike(trackId: Long) {
        val current = _likedTracks.value.toMutableSet()
        if (current.contains(trackId)) {
            current.remove(trackId)
        } else {
            current.add(trackId)
        }
        _likedTracks.value = current
        saveLikedTracks()
    }

    private val _dominantColor = MutableStateFlow<Int?>(null)
    val dominantColor = _dominantColor.asStateFlow()

    private val _gradientColors = MutableStateFlow<List<Int>>(emptyList())
    val gradientColors = _gradientColors.asStateFlow()

    private var mediaSession: MediaSessionCompat? = null

    private val mediaReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "ACTION_PLAY_PAUSE" -> togglePlayPause()
                "ACTION_NEXT" -> playNext(getApplication())
                "ACTION_PREV" -> playPrev(getApplication())
            }
        }
    }

    init {
        try {
            castContext = CastContext.getSharedInstance(application)
            castContext?.sessionManager?.addSessionManagerListener(sessionManagerListener, CastSession::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mediaSession = MediaSessionCompat(application, "AurisSession")
        mediaSession?.setCallback(object : MediaSessionCompat.Callback() {
            override fun onSeekTo(pos: Long) {
                val totalDuration = mediaPlayer?.duration ?: return
                if (totalDuration > 0) {
                    seekTo(pos.toFloat() / totalDuration)
                }
            }
            override fun onPlay() {
                if (!_isPlaying.value) togglePlayPause()
            }
            override fun onPause() {
                if (_isPlaying.value) togglePlayPause()
            }
            override fun onSkipToNext() {
                playNext(getApplication())
            }
            override fun onSkipToPrevious() {
                playPrev(getApplication())
            }
        })
        val filter = IntentFilter().apply {
            addAction("ACTION_PLAY_PAUSE")
            addAction("ACTION_NEXT")
            addAction("ACTION_PREV")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            application.registerReceiver(mediaReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            application.registerReceiver(mediaReceiver, filter)
        }

        // Tracker coroutine
        viewModelScope.launch {
            loadPlaylists()
            loadLikedTracks()
            while (isActive) {
                mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        val current = player.currentPosition
                        val total = player.duration
                        if (total > 0) {
                            _progress.value = current.toFloat() / total.toFloat()
                            _currentTimeMs.value = current.toLong()
                        }
                    }
                }
                delay(100)
            }
        }
    }

    private fun updateMediaSessionState() {
        val track = currentTrack.value ?: return
        val player = mediaPlayer ?: return
        
        val state = if (_isPlaying.value) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
        val position = player.currentPosition.toLong()
        
        mediaSession?.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setState(state, position, 1f, SystemClock.elapsedRealtime())
                .setActions(PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_SEEK_TO)
                .build()
        )
    }

    private fun updateNotification() {
        val track = currentTrack.value ?: return
        val context = getApplication<android.app.Application>()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("auris_media", "Media Playback", NotificationManager.IMPORTANCE_LOW)
            notificationManager.createNotificationChannel(channel)
        }

        var bitmap: Bitmap? = null
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(context.contentResolver, track.albumArtUri)
                bitmap = ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
            } else {
                @Suppress("DEPRECATION")
                bitmap = MediaStore.Images.Media.getBitmap(context.contentResolver, track.albumArtUri)
            }
            
            // Scale down the bitmap to avoid TransactionTooLargeException in notification
            if (bitmap != null && (bitmap.width > 512 || bitmap.height > 512)) {
                val ratio = kotlin.math.min(512f / bitmap.width, 512f / bitmap.height)
                bitmap = Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            bitmap = null
        }
        
        mediaSession?.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, track.title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, track.artist)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, track.duration)
                .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, bitmap)
                .build()
        )
        mediaSession?.isActive = true
        updateMediaSessionState()

        val playPauseAction = NotificationCompat.Action(
            if (_isPlaying.value) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
            "Play/Pause",
            PendingIntent.getBroadcast(context, 0, Intent("ACTION_PLAY_PAUSE").setPackage(context.packageName), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        )
        val nextAction = NotificationCompat.Action(
            android.R.drawable.ic_media_next,
            "Next",
            PendingIntent.getBroadcast(context, 1, Intent("ACTION_NEXT").setPackage(context.packageName), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        )
        val prevAction = NotificationCompat.Action(
            android.R.drawable.ic_media_previous,
            "Previous",
            PendingIntent.getBroadcast(context, 2, Intent("ACTION_PREV").setPackage(context.packageName), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        )

        var dominantColor = 0
        if (bitmap != null) {
            val palette = Palette.from(bitmap).generate()
            dominantColor = palette.getDominantColor(0)
            _dominantColor.value = if (dominantColor != 0) dominantColor else null

            val list = mutableListOf<Int>()
            val dom = palette.getDominantColor(0)
            val vib = palette.getVibrantColor(0)
            val mut = palette.getMutedColor(0)
            val dVib = palette.getDarkVibrantColor(0)
            val dMut = palette.getDarkMutedColor(0)
            val lVib = palette.getLightVibrantColor(0)
            val lMut = palette.getLightMutedColor(0)

            if (dom != 0) list.add(dom)
            if (vib != 0) list.add(vib)
            if (dVib != 0) list.add(dVib)
            if (dMut != 0) list.add(dMut)
            if (mut != 0) list.add(mut)
            if (lVib != 0) list.add(lVib)
            if (lMut != 0) list.add(lMut)

            _gradientColors.value = list.distinct()
        } else {
            _dominantColor.value = null
            _gradientColors.value = emptyList()
        }

        val notificationBuilder = NotificationCompat.Builder(context, "auris_media")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setLargeIcon(bitmap)
            .setContentTitle(track.title)
            .setContentText(track.artist)
            .setOngoing(_isPlaying.value)
            .addAction(prevAction)
            .addAction(playPauseAction)
            .addAction(nextAction)
            .setStyle(androidx.media.app.NotificationCompat.MediaStyle()
                .setShowActionsInCompactView(0, 1, 2)
                .setMediaSession(mediaSession?.sessionToken)
            )

        if (dominantColor != 0) {
            notificationBuilder.setColor(dominantColor)
                .setColorized(true)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    notificationManager.notify(1, notificationBuilder.build())
                }
            } else {
                notificationManager.notify(1, notificationBuilder.build())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadTracks(context: Context) {
        val trackList = mutableListOf<AudioTrack>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.ALBUM
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"
        
        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)

            val artworkUri = Uri.parse("content://media/external/audio/albumart")

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val title = cursor.getString(titleColumn) ?: "Unknown Title"
                val artist = cursor.getString(artistColumn) ?: "Unknown Artist"
                val duration = cursor.getLong(durationColumn)
                val albumId = cursor.getLong(albumIdColumn)
                val dataPath = cursor.getString(dataColumn)
                val album = cursor.getString(albumColumn) ?: "Unknown Album"
                val folderName = try {
                    java.io.File(dataPath).parentFile?.name ?: "Unknown Folder"
                } catch (e: Exception) {
                    "Unknown Folder"
                }

                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                val albumArtUri = ContentUris.withAppendedId(artworkUri, albumId)

                trackList.add(
                    AudioTrack(id, title, artist, duration, albumId, uri, albumArtUri, folderName, album)
                )
            }
        }
        _tracks.value = trackList
        _filteredTracks.value = trackList
        
        val historyStrs = prefs.getString("play_history", "") ?: ""
        val historyIds = if (historyStrs.isEmpty()) emptyList() else historyStrs.split(",").mapNotNull { it.toLongOrNull() }
        val loadedHistory = historyIds.mapNotNull { id -> trackList.find { it.id == id } }
        _playHistory.value = loadedHistory
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _filteredTracks.value = _tracks.value
        } else {
            _filteredTracks.value = _tracks.value.filter {
                it.title.contains(query, ignoreCase = true) || it.artist.contains(query, ignoreCase = true)
            }
        }
    }

    fun toggleShuffle() {
        _isShuffleEnabled.value = !_isShuffleEnabled.value
    }

    fun toggleLoop() {
        _isLoopEnabled.value = !_isLoopEnabled.value
        mediaPlayer?.isLooping = _isLoopEnabled.value
    }

    private val _playHistory = MutableStateFlow<List<AudioTrack>>(emptyList())
    val playHistory = _playHistory.asStateFlow()

    private val _currentLyrics = MutableStateFlow<List<LyricLine>>(emptyList())
    val currentLyrics = _currentLyrics.asStateFlow()

    private val _isFetchingLyrics = MutableStateFlow(false)
    val isFetchingLyrics = _isFetchingLyrics.asStateFlow()

    private val _lyricsSource = MutableStateFlow("")
    val lyricsSource = _lyricsSource.asStateFlow()

    private fun loadLyricsForCurrentTrack() {
        val track = currentTrack.value
        if (track != null) {
            val lrc = prefs.getString("lyrics_${track.id}", null)
            if (lrc != null && lrc.trim().isNotEmpty()) {
                _currentLyrics.value = parseLrc(lrc)
                _lyricsSource.value = "Local cache"
            } else {
                _currentLyrics.value = emptyList()
                fetchLyricsAutomatically(track)
            }
        } else {
            _currentLyrics.value = emptyList()
            _lyricsSource.value = ""
        }
    }

    fun fetchLyricsAutomatically(track: AudioTrack) {
        if (_isFetchingLyrics.value) return
        _isFetchingLyrics.value = true
        _lyricsSource.value = "Connecting to multiple lyrics libraries..."
        _currentLyrics.value = emptyList()
        
        viewModelScope.launch(Dispatchers.IO) {
            var lyricsContent: String? = null
            var source = ""
            
            // 1. Try LRCLIB first
            try {
                lyricsContent = fetchFromLrcLib(track.title, track.artist, track.duration)
                if (!lyricsContent.isNullOrBlank()) {
                    source = "LRCLIB (Synced)"
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            
            // 2. Try Lyrics.ovh as secondary library
            if (lyricsContent.isNullOrBlank()) {
                try {
                    lyricsContent = fetchFromLyricsOvh(track.title, track.artist)
                    if (!lyricsContent.isNullOrBlank()) {
                        source = "Lyrics.ovh"
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            
            // 3. Try Gemini AI as tertiary library
            if (lyricsContent.isNullOrBlank()) {
                try {
                    lyricsContent = fetchFromGemini(track.title, track.artist)
                    if (!lyricsContent.isNullOrBlank()) {
                        source = "Gemini AI"
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            
            withContext(Dispatchers.Main) {
                if (currentTrack.value?.id == track.id) {
                    if (!lyricsContent.isNullOrBlank()) {
                        saveLyricsForCurrentTrack(lyricsContent)
                        _lyricsSource.value = "Fetched from $source"
                    } else {
                        _lyricsSource.value = "No lyrics found in any library"
                    }
                } else if (!lyricsContent.isNullOrBlank()) {
                    // Just save to cache for future playback
                    prefs.edit().putString("lyrics_${track.id}", lyricsContent).apply()
                }
                _isFetchingLyrics.value = false
            }
        }
    }

    private fun fetchFromLrcLib(title: String, artist: String, durationMs: Long): String? {
        val client = OkHttpClient.Builder()
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .build()
            
        val cleanArtist = artist.trim()
        val cleanTitle = title.trim()
        
        // Exact GET endpoint
        val url = "https://lrclib.net/api/get?" +
                "artist_name=${URLEncoder.encode(cleanArtist, "UTF-8")}" +
                "&track_name=${URLEncoder.encode(cleanTitle, "UTF-8")}" +
                "&duration=${durationMs / 1000}"
                
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "AurisMusicPlayer/1.0 (https://github.com/example/Auris)")
            .get()
            .build()
            
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string() ?: return null
                    val json = JSONObject(bodyStr)
                    val synced = json.optString("syncedLyrics")
                    if (!synced.isNullOrBlank() && synced != "null") {
                        return synced
                    }
                    val plain = json.optString("plainLyrics")
                    if (!plain.isNullOrBlank() && plain != "null") {
                        return convertToPseudoLrc(plain)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        // Fallback search endpoint
        val searchUrl = "https://lrclib.net/api/search?q=" + 
                URLEncoder.encode("$cleanArtist $cleanTitle", "UTF-8")
                
        val searchRequest = Request.Builder()
            .url(searchUrl)
            .header("User-Agent", "AurisMusicPlayer/1.0 (https://github.com/example/Auris)")
            .get()
            .build()
            
        try {
            client.newCall(searchRequest).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string() ?: return null
                    val arr = JSONArray(bodyStr)
                    if (arr.length() > 0) {
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            val synced = obj.optString("syncedLyrics")
                            if (!synced.isNullOrBlank() && synced != "null") {
                                return synced
                            }
                        }
                        val firstObj = arr.getJSONObject(0)
                        val plain = firstObj.optString("plainLyrics")
                        if (!plain.isNullOrBlank() && plain != "null") {
                            return convertToPseudoLrc(plain)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private fun fetchFromLyricsOvh(title: String, artist: String): String? {
        val client = OkHttpClient.Builder()
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .build()
            
        val url = "https://api.lyrics.ovh/v1/${URLEncoder.encode(artist.trim(), "UTF-8")}/${URLEncoder.encode(title.trim(), "UTF-8")}"
        
        val request = Request.Builder()
            .url(url)
            .get()
            .build()
            
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string() ?: return null
                    val json = JSONObject(bodyStr)
                    val lyrics = json.optString("lyrics")
                    if (!lyrics.isNullOrBlank()) {
                        val cleanLyrics = lyrics.replace(Regex("(?i)Paroles de .* de .*\\n"), "")
                        return convertToPseudoLrc(cleanLyrics)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private fun fetchFromGemini(title: String, artist: String): String? {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return null
        }
        
        val client = OkHttpClient.Builder()
            .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .build()
            
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        
        val requestJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "You are an expert music database. Please find and return the lyrics for the song '$title' by '$artist'. " +
                                    "If possible, format the lyrics in standard synchronized LRC format (with timestamps like [01:23.45] at the beginning of each line). " +
                                    "If you don't know the exact timestamps, output plain lyrics but prepend sequential dummy timestamps spaced by 4 seconds (e.g., [00:01.00] line 1, [00:05.00] line 2, etc.) " +
                                    "so they sync correctly with a media player's LRC parsing regex. " +
                                    "Return ONLY the raw LRC content. " +
                                    "Strictly avoid any markdown packaging (do not use ```lrc or ```), conversational preambles, notes, or intros. Just output the lines of lyrics.")
                        })
                    })
                })
            })
        }
        
        val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
        val body = requestJson.toString().toRequestBody(mediaType)
        
        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()
            
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseStr = response.body?.string() ?: return null
                    val json = JSONObject(responseStr)
                    val candidates = json.optJSONArray("candidates")
                    val firstCandidate = candidates?.optJSONObject(0)
                    val content = firstCandidate?.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val firstPart = parts?.optJSONObject(0)
                    val rawText = firstPart?.optString("text")
                    
                    if (!rawText.isNullOrBlank()) {
                        return rawText
                            .replace(Regex("(?s)```[a-zA-Z]*\\n"), "")
                            .replace("```", "")
                            .trim()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private fun convertToPseudoLrc(plainText: String): String {
        val lines = plainText.split("\n")
        val sb = java.lang.StringBuilder()
        var currentMs = 1000L
        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isNotEmpty()) {
                val min = currentMs / 60000
                val sec = (currentMs % 60000) / 1000
                val ms = (currentMs % 1000) / 10
                sb.append(String.format("[%02d:%02d.%02d] %s\n", min, sec, ms, trimmed))
                currentMs += 4000L
            }
        }
        return sb.toString()
    }

    fun saveLyricsForCurrentTrack(content: String) {
        val track = currentTrack.value
        if (track != null) {
            prefs.edit().putString("lyrics_${track.id}", content).apply()
            _currentLyrics.value = parseLrc(content)
        }
    }

    private fun addToHistory(track: AudioTrack) {
        val current = _playHistory.value.toMutableList()
        current.remove(track)
        current.add(0, track)
        if (current.size > 50) {
            current.removeAt(current.size - 1)
        }
        _playHistory.value = current
        savePlayHistory()
    }

    fun playTrack(track: AudioTrack, context: Context) {
        mediaPlayer?.release()
        try {
            _currentTrack.value = track
            loadLyricsForCurrentTrack()
            addToHistory(track)
            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, track.uri)
                prepare()
                
                // Set Up Audio Effects
                try {
                    val leftVol = if (_balance.value < 0) 1f else 1f - _balance.value
                    val rightVol = if (_balance.value > 0) 1f else 1f + _balance.value
                    setVolume(_volume.value * leftVol, _volume.value * rightVol)

                    equalizer?.release()
                    equalizer = Equalizer(0, audioSessionId).apply {
                        enabled = true
                        minEqLevel = bandLevelRange[0]
                        maxEqLevel = bandLevelRange[1]
                        updateEqBands()
                    }
                    bassBoost?.release()
                    bassBoost = BassBoost(0, audioSessionId).apply {
                        enabled = true
                        setStrength((_bassBoostLevel.value * 1000).toInt().toShort())
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        playbackParams = playbackParams.setSpeed(_playbackSpeed.value)
                    }
                } catch (e: Exception) { e.printStackTrace() }

                start()
                isLooping = _isLoopEnabled.value
                setOnCompletionListener {
                    if (!isLooping) {
                        _isPlaying.value = false
                        updateNotification()
                        playNext(context)
                    }
                }
            }
            _isPlaying.value = true
            updateNotification()
            if (castSession != null) {
                streamCurrentSongToTv()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun togglePlayPause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _isPlaying.value = false
                updateNotification()
            } else {
                it.start()
                _isPlaying.value = true
                updateNotification()
            }
            if (castSession != null) {
                syncPlaybackStateToTv()
            }
        }
    }

    fun playNext(context: Context) {
        val current = _currentTrack.value ?: return
        val list = _playbackQueue.value.ifEmpty { _filteredTracks.value }
        if (list.isEmpty()) return
        
        if (_isShuffleEnabled.value) {
            playTrack(list.random(), context)
            return
        }
        
        val idx = list.indexOf(current)
        if (idx != -1 && idx < list.size - 1) {
            playTrack(list[idx + 1], context)
        } else if (list.isNotEmpty()) {
            playTrack(list[0], context)
        }
    }

    fun playPrev(context: Context) {
        val current = _currentTrack.value ?: return
        val list = _playbackQueue.value.ifEmpty { _filteredTracks.value }
        if (list.isEmpty()) return
        
        if (_isShuffleEnabled.value) {
            playTrack(list.random(), context)
            return
        }

        val idx = list.indexOf(current)
        if (idx > 0) {
            playTrack(list[idx - 1], context)
        } else if (list.isNotEmpty()) {
            playTrack(list.last(), context)
        }
    }

    private fun updateEqBands() {
        equalizer?.let { eq ->
            for (i in 0 until minOf(eq.numberOfBands.toInt(), 5)) {
                val levelTarget = _eqLevels.value[i]
                val level = if (levelTarget >= 0) {
                    (levelTarget * maxEqLevel).toInt().toShort()
                } else {
                    (levelTarget * -minEqLevel).toInt().toShort()
                }
                eq.setBandLevel(i.toShort(), level)
            }
        }
    }

    fun setEqBand(band: Int, value: Float) {
        val updated = _eqLevels.value.toMutableList()
        if (band in updated.indices) {
            updated[band] = value
            _eqLevels.value = updated
            updateEqBands()
        }
    }

    fun setBassBoost(value: Float) {
        _bassBoostLevel.value = value
        bassBoost?.setStrength((value * 1000).toInt().toShort())
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        mediaPlayer?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    it.playbackParams = it.playbackParams.setSpeed(speed)
                } catch (e: Exception) { e.printStackTrace() }
            }
        }
    }

    fun setVolumeLevel(vol: Float) {
        _volume.value = vol
        updatePlayerVolume()
    }

    fun setBalance(bal: Float) {
        _balance.value = bal
        updatePlayerVolume()
    }

    private fun updatePlayerVolume() {
        if (castSession != null) {
            mediaPlayer?.setVolume(0f, 0f)
            return
        }
        val leftVol = if (_balance.value < 0) 1f else 1f - _balance.value
        val rightVol = if (_balance.value > 0) 1f else 1f + _balance.value
        mediaPlayer?.setVolume(_volume.value * leftVol, _volume.value * rightVol)
    }

    fun seekTo(fraction: Float) {
        mediaPlayer?.let {
            val position = (it.duration * fraction).toInt()
            it.seekTo(position)
            _progress.value = fraction
            _currentTimeMs.value = position.toLong()
            updateMediaSessionState()
            if (castSession != null) {
                syncPlaybackStateToTv()
            }
        }
    }

    fun seekToMs(positionMs: Long) {
        mediaPlayer?.let {
            val duration = it.duration
            if (duration > 0) {
                val clamped = positionMs.coerceIn(0L, duration.toLong()).toInt()
                it.seekTo(clamped)
                _progress.value = clamped.toFloat() / duration
                _currentTimeMs.value = clamped.toLong()
                updateMediaSessionState()
                if (castSession != null) {
                    syncPlaybackStateToTv()
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopDiscovery()
        stopLocalServer()
        try {
            castContext?.sessionManager?.removeSessionManagerListener(sessionManagerListener, CastSession::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val context = getApplication<android.app.Application>()
        try {
            context.unregisterReceiver(mediaReceiver)
        } catch (e: Exception) {}
        mediaSession?.release()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(1)
        mediaPlayer?.release()
        mediaPlayer = null
    }
}

@Composable
fun AurisGradientBackground(
    dominantColor: Color?,
    gradientColors: List<Color> = emptyList(),
    modifier: Modifier = Modifier
) {
    val defaultBase = dominantColor ?: Color(0xFF23123A)
    
    val animatedC1 by animateColorAsState(
        targetValue = gradientColors.getOrNull(0) ?: defaultBase,
        animationSpec = tween(durationMillis = 1000, easing = LinearOutSlowInEasing),
        label = "c1Animation"
    )
    val animatedC2 by animateColorAsState(
        targetValue = gradientColors.getOrNull(1) ?: gradientColors.getOrNull(0) ?: defaultBase,
        animationSpec = tween(durationMillis = 1000, easing = LinearOutSlowInEasing),
        label = "c2Animation"
    )
    val animatedC3 by animateColorAsState(
        targetValue = gradientColors.getOrNull(2) ?: gradientColors.getOrNull(1) ?: Color(0xFF060408),
        animationSpec = tween(durationMillis = 1000, easing = LinearOutSlowInEasing),
        label = "c3Animation"
    )

    val topColor = remember(animatedC1) {
        Color(ColorUtils.blendARGB(animatedC1.toArgb(), Color.Black.toArgb(), 0.15f))
    }
    val middleColor = remember(animatedC2) {
        Color(ColorUtils.blendARGB(animatedC2.toArgb(), Color.Black.toArgb(), 0.50f))
    }
    val bottomColor = remember(animatedC3) {
        Color(ColorUtils.blendARGB(animatedC3.toArgb(), Color.Black.toArgb(), 0.85f))
    }

    val infiniteTransition = rememberInfiniteTransition(label = "gradientMovement")
    val animatedShift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 15000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "gradientShift"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                val height = size.height
                val width = size.width

                // Slowly move the start position at the top
                val startX = width * 0.3f * animatedShift
                val startY = -height * 0.1f + (height * 0.2f * (1f - animatedShift))

                // Slowly move the end position at the bottom
                val endX = width * (0.7f + 0.3f * animatedShift)
                val endY = height * (1.1f - 0.2f * (1f - animatedShift))

                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(topColor, middleColor, bottomColor),
                        start = Offset(startX, startY),
                        end = Offset(endX, endY)
                    ),
                    size = size
                )
            }
    )
}

fun formatTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AurisApp(viewModel: AurisViewModel = viewModel(), modifier: Modifier = Modifier) {
    val context = LocalContext.current
    
    val permissionsToRequest = mutableListOf<String>()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
        permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
    } else {
        permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    
    val permissionsState = rememberMultiplePermissionsState(permissionsToRequest)
    
    var showEqDialog by remember { mutableStateOf(false) }
    var trackOptionsTrack by remember { mutableStateOf<AudioTrack?>(null) }
    var showCreatePlaylistDialog by remember { mutableStateOf<AudioTrack?>(null) }
    var showQueueSheet by remember { mutableStateOf(false) }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Home", "Library", "Albums", "Favorites", "Playlists", "Folders", "History")
    val tabIcons = listOf(
        Icons.Default.Home,
        Icons.Default.LibraryMusic,
        Icons.Default.Album,
        Icons.Default.FavoriteBorder,
        Icons.Default.PlaylistPlay,
        Icons.Default.FolderOpen,
        Icons.Default.History
    )
    val tabIconsSelected = listOf(
        Icons.Default.Home,
        Icons.Default.LibraryMusic,
        Icons.Default.Album,
        Icons.Default.Favorite,
        Icons.Default.PlaylistPlay,
        Icons.Default.Folder,
        Icons.Default.History
    )
    var selectedFolder by remember { mutableStateOf<String?>(null) }
    var selectedPlaylist by remember { mutableStateOf<String?>(null) }
    var selectedAlbum by remember { mutableStateOf<String?>(null) }
    
    BackHandler(enabled = selectedFolder != null) {
        selectedFolder = null
    }

    BackHandler(enabled = selectedPlaylist != null) {
        selectedPlaylist = null
    }

    BackHandler(enabled = selectedAlbum != null) {
        selectedAlbum = null
    }
    
    LaunchedEffect(selectedTabIndex) {
        if (selectedTabIndex != 5) selectedFolder = null
        if (selectedTabIndex != 4) selectedPlaylist = null
        if (selectedTabIndex != 2) selectedAlbum = null
    }

    val currentTrack by viewModel.currentTrack.collectAsState()
    var showFullPlayer by remember { mutableStateOf(false) }

    BackHandler(enabled = showFullPlayer) {
        showFullPlayer = false
    }

    LaunchedEffect(permissionsState.allPermissionsGranted) {
        if (permissionsState.allPermissionsGranted) {
            viewModel.loadTracks(context)
        } else {
            permissionsState.launchMultiplePermissionRequest()
        }
    }

    val dominantColorInt by viewModel.dominantColor.collectAsState()
    val dominantColor = dominantColorInt?.let { Color(it) }
    val gradientColorsInt by viewModel.gradientColors.collectAsState()
    val gradientColors = remember(gradientColorsInt) { gradientColorsInt.map { Color(it) } }

    Box(modifier = modifier.fillMaxSize()) {
        AurisGradientBackground(dominantColor = dominantColor, gradientColors = gradientColors)
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        "Auris",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        "for the ear",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Light,
                        letterSpacing = 1.sp
                    )
                }
                
                IconButton(onClick = { showEqDialog = true }) {
                    Icon(
                        Icons.Default.Tune,
                        contentDescription = "Equalizer",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            val searchQuery by viewModel.searchQuery.collectAsState()
            OutlinedTextField(
                value = searchQuery,
                onValueChange = viewModel::updateSearchQuery,
                placeholder = { Text("Search tracks, artists...", color = MaterialTheme.colorScheme.secondary) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.secondary) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                    focusedTextColor = MaterialTheme.colorScheme.onBackground,
                    unfocusedTextColor = MaterialTheme.colorScheme.onBackground,
                    cursorColor = MaterialTheme.colorScheme.primary
                ),
                shape = CircleShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 16.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (!permissionsState.allPermissionsGranted) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Storage permission required to find local audio files.", color = MaterialTheme.colorScheme.secondary)
                }
            } else {
                val filteredTracks by viewModel.filteredTracks.collectAsState()
                val currentTrack by viewModel.currentTrack.collectAsState()
                val likedTracks by viewModel.likedTracks.collectAsState()
                val playHistory by viewModel.playHistory.collectAsState()
                val playlists by viewModel.playlists.collectAsState()
                val playbackQueue by viewModel.playbackQueue.collectAsState()
                
                if (selectedTabIndex == 0 && searchQuery.isBlank()) {
                    HomeScreen(
                        filteredTracks = filteredTracks,
                        playHistory = playHistory,
                        playlists = playlists,
                        onTrackClick = { track, tracks ->
                            viewModel.playTrackFromContext(track, tracks, context)
                        },
                        onPlaylistClick = { pl ->
                            selectedPlaylist = pl
                            selectedTabIndex = 4
                        },
                        onAlbumClick = { album ->
                            selectedAlbum = album
                            selectedTabIndex = 2
                        },
                        onNavigateToTab = { index ->
                            selectedTabIndex = index
                        },
                        modifier = Modifier.weight(1f)
                    )
                } else if (selectedTabIndex == 2 && selectedAlbum == null) {
                    val albumNames = filteredTracks.map { it.album }.distinct().sorted()
                    if (albumNames.isEmpty()) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text("No albums found.", color = MaterialTheme.colorScheme.secondary)
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                            contentPadding = PaddingValues(bottom = 120.dp, top = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            items(albumNames) { albumName ->
                                val albumTracks = filteredTracks.filter { it.album == albumName }
                                val firstTrack = albumTracks.firstOrNull()
                                val cover = firstTrack?.albumArtUri ?: Uri.EMPTY
                                val artist = firstTrack?.artist ?: "Unknown Artist"
                                AlbumCard(
                                    name = albumName,
                                    artist = artist,
                                    cover = cover,
                                    onClick = { selectedAlbum = albumName }
                                )
                            }
                        }
                    }
                } else if (selectedTabIndex == 5 && selectedFolder == null) {
                    val folders = filteredTracks.map { it.folderName }.distinct().sorted()
                    if (folders.isEmpty()) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text("No folders found.", color = MaterialTheme.colorScheme.secondary)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(bottom = 120.dp)
                        ) {
                            items(folders) { folder ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedFolder = folder }
                                        .padding(horizontal = 24.dp, vertical = 16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text(folder, fontSize = 18.sp, color = MaterialTheme.colorScheme.onBackground)
                                }
                            }
                        }
                    }
                } else if (selectedTabIndex == 4 && selectedPlaylist == null) {
                    val playlistNames = playlists.keys.toList()
                    Column(modifier = Modifier.weight(1f)) {
                        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { showCreatePlaylistDialog = AudioTrack(0, "", "", 0, 0, Uri.EMPTY, Uri.EMPTY, "", "") }) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("New Playlist")
                            }
                        }
                        if (playlistNames.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No playlists yet.", color = MaterialTheme.colorScheme.secondary)
                            }
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(2),
                                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                                contentPadding = PaddingValues(bottom = 120.dp, top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                items(playlistNames) { pl ->
                                    val trackIds = playlists[pl] ?: emptyList()
                                    val covers = trackIds.mapNotNull { id -> filteredTracks.find { it.id == id }?.albumArtUri }.take(4)
                                    PlaylistCard(name = pl, covers = covers, onClick = { selectedPlaylist = pl })
                                }
                            }
                        }
                    }
                } else {
                    val displayTracks = when (selectedTabIndex) {
                        2 -> filteredTracks.filter { it.album == selectedAlbum }
                        3 -> filteredTracks.filter { likedTracks.contains(it.id) }
                        4 -> filteredTracks.filter { playlists[selectedPlaylist]?.contains(it.id) == true }
                        5 -> filteredTracks.filter { it.folderName == selectedFolder }
                        6 -> playHistory.filter { filteredTracks.contains(it) }
                        else -> filteredTracks
                    }
                    
                    if (displayTracks.isEmpty()) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(64.dp))
                                Spacer(Modifier.height(16.dp))
                                val msg = when(selectedTabIndex) {
                                    2 -> "Empty album."
                                    3 -> "No favorites yet."
                                    4 -> "Empty playlist."
                                    5 -> "Empty folder."
                                    6 -> "No history yet."
                                    else -> "No audio files found."
                                }
                                Text(msg, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    } else {
                        Column(modifier = Modifier.weight(1f)) {
                            if (selectedTabIndex == 2 && selectedAlbum != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { selectedAlbum = null }) {
                                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(selectedAlbum!!, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                }
                            }
                            if (selectedTabIndex == 5 && selectedFolder != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { selectedFolder = null }) {
                                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(selectedFolder!!, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                }
                            }
                            if (selectedTabIndex == 4 && selectedPlaylist != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { selectedPlaylist = null }) {
                                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(selectedPlaylist!!, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                    Spacer(modifier = Modifier.weight(1f))
                                    IconButton(onClick = { viewModel.deletePlaylist(selectedPlaylist!!); selectedPlaylist = null }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(bottom = 120.dp) // Padding for bottom player
                            ) {
                                items(displayTracks) { track ->
                                    val isSelected = currentTrack?.id == track.id
                                    val isLiked = likedTracks.contains(track.id)
                                    TrackItem(
                                        track = track, 
                                        isSelected = isSelected, 
                                        isLiked = isLiked, 
                                        onLikeClick = { viewModel.toggleLike(track.id) },
                                        onOptionsClick = { trackOptionsTrack = track }
                                    ) {
                                        viewModel.playTrackFromContext(track, displayTracks, context)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            // Bottom Sheet for Track Options
            if (trackOptionsTrack != null) {
                ModalBottomSheet(onDismissRequest = { trackOptionsTrack = null }) {
                    Column(modifier = Modifier.padding(bottom = 32.dp)) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Options", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        ListItem(
                            headlineContent = { Text("Play Next") },
                            leadingContent = { Icon(Icons.Default.PlaylistPlay, contentDescription = null) },
                            modifier = Modifier.clickable {
                                viewModel.playNextInQueue(trackOptionsTrack!!)
                                trackOptionsTrack = null
                            }
                        )
                        ListItem(
                            headlineContent = { Text("Add to Queue") },
                            leadingContent = { Icon(Icons.Default.QueueMusic, contentDescription = null) },
                            modifier = Modifier.clickable {
                                viewModel.addTrackToQueue(trackOptionsTrack!!)
                                trackOptionsTrack = null
                            }
                        )
                        ListItem(
                            headlineContent = { Text("Add to Playlist") },
                            leadingContent = { Icon(Icons.Default.PlaylistAdd, contentDescription = null) },
                            modifier = Modifier.clickable {
                                showCreatePlaylistDialog = trackOptionsTrack
                                trackOptionsTrack = null
                            }
                        )
                    }
                }
            }

            if (showCreatePlaylistDialog != null) {
                val track = showCreatePlaylistDialog
                var newPlName by remember { mutableStateOf("") }
                val playlists by viewModel.playlists.collectAsState()
                
                AlertDialog(
                    onDismissRequest = { showCreatePlaylistDialog = null },
                    title = { Text("Add to Playlist") },
                    text = {
                        Column {
                            if (playlists.isNotEmpty()) {
                                Text("Existing Playlists", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                                LazyColumn(modifier = Modifier.heightIn(max = 200.dp)) {
                                    items(playlists.keys.toList()) { pl ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth().clickable {
                                                if (track?.id != 0L) viewModel.addTrackToPlaylist(pl, track!!.id)
                                                showCreatePlaylistDialog = null
                                            }.padding(vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.QueueMusic, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Text(pl)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                            }
                            OutlinedTextField(
                                value = newPlName,
                                onValueChange = { newPlName = it },
                                label = { Text("New Playlist Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (newPlName.isNotBlank()) {
                                viewModel.createPlaylist(newPlName)
                                if (track?.id != 0L) viewModel.addTrackToPlaylist(newPlName, track!!.id)
                                showCreatePlaylistDialog = null
                            }
                        }) { Text("Create") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showCreatePlaylistDialog = null }) { Text("Cancel") }
                    }
                )
            }
        }

        if (showEqDialog) {
            EqSettingsDialog(viewModel = viewModel, onDismiss = { showEqDialog = false })
        }

        // Bottom Area (Now Playing Bar + Navigation Bar)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Playing song bar
            AnimatedVisibility(
                visible = currentTrack != null && !showFullPlayer,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                currentTrack?.let { track ->
                    BottomPlayerPanel(
                        track = track,
                        viewModel = viewModel,
                        onClick = { showFullPlayer = true },
                        modifier = Modifier
                            .widthIn(max = 380.dp)
                            .fillMaxWidth(0.82f)
                    )
                }
            }

            // Custom Bottom Section Bar
            AnimatedVisibility(
                visible = !showFullPlayer,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                CustomSectionBar(
                    selectedTabIndex = selectedTabIndex,
                    onTabSelected = { selectedTabIndex = it },
                    tabs = tabs,
                    tabIcons = tabIcons,
                    tabIconsSelected = tabIconsSelected
                )
            }
        }

        // Full Screen Player
        AnimatedVisibility(
            visible = showFullPlayer,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            currentTrack?.let { track ->
                FullPlayerScreen(
                    track = track, 
                    viewModel = viewModel, 
                    onClose = { showFullPlayer = false },
                    onOptionsClick = { trackOptionsTrack = track }
                )
            }
        }
    }
}

@Composable
fun EqSettingsDialog(viewModel: AurisViewModel, onDismiss: () -> Unit) {
    val eqLevels by viewModel.eqLevels.collectAsState()
    val bassBoostLevel by viewModel.bassBoostLevel.collectAsState()
    val playbackSpeed by viewModel.playbackSpeed.collectAsState()
    val volume by viewModel.volume.collectAsState()
    val balance by viewModel.balance.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Audio Settings", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn {
                item {
                    Text("Master Volume", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                    EqSlider("Volume", volume, valueRange = 0f..1f, onValueChange = { viewModel.setVolumeLevel(it) })
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("L/R Balance", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                    EqSlider("Balance", balance, valueRange = -1f..1f, onValueChange = { viewModel.setBalance(it) })

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Playback Speed", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Text("${String.format("%.1f", playbackSpeed)}x", modifier = Modifier.width(56.dp), fontSize = 14.sp)
                        Slider(
                            value = playbackSpeed,
                            onValueChange = { viewModel.setPlaybackSpeed(it) },
                            valueRange = 0.5f..2.0f,
                            steps = 5,
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Equalizer", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    EqSlider("Bass (60Hz)", eqLevels[0], valueRange = -1f..1f, onValueChange = { viewModel.setEqBand(0, it) })
                    EqSlider("Mid (230Hz)", eqLevels[1], valueRange = -1f..1f, onValueChange = { viewModel.setEqBand(1, it) })
                    EqSlider("Mid (910Hz)", eqLevels[2], valueRange = -1f..1f, onValueChange = { viewModel.setEqBand(2, it) })
                    EqSlider("Mid (3kHz)", eqLevels[3], valueRange = -1f..1f, onValueChange = { viewModel.setEqBand(3, it) })
                    EqSlider("Treble (14kHz)", eqLevels[4], valueRange = -1f..1f, onValueChange = { viewModel.setEqBand(4, it) })
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Bass Boost", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                    EqSlider("Strength", bassBoostLevel, valueRange = 0f..1f, onValueChange = { viewModel.setBassBoost(it) })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = MaterialTheme.colorScheme.primary)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        titleContentColor = MaterialTheme.colorScheme.onSurface,
        textContentColor = MaterialTheme.colorScheme.onSurface
    )
}

@Composable
fun EqSlider(label: String, value: Float, valueRange: ClosedFloatingPointRange<Float>, onValueChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, modifier = Modifier.width(80.dp), fontSize = 14.sp)
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        )
    }
}

@Composable
fun PlaylistCoverImage(uri: Uri, modifier: Modifier = Modifier) {
    Box(modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        if (uri != Uri.EMPTY) {
            AsyncImage(
                model = uri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
fun PlaylistCard(name: String, covers: List<Uri>, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (covers.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.QueueMusic, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(48.dp))
                    }
                } else if (covers.size == 1) {
                    PlaylistCoverImage(uri = covers[0], modifier = Modifier.fillMaxSize())
                } else if (covers.size == 2 || covers.size == 3) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        PlaylistCoverImage(uri = covers[0], modifier = Modifier.weight(1f).fillMaxHeight())
                        PlaylistCoverImage(uri = covers[1], modifier = Modifier.weight(1f).fillMaxHeight())
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            PlaylistCoverImage(uri = covers[0], modifier = Modifier.weight(1f).fillMaxHeight())
                            PlaylistCoverImage(uri = covers[1], modifier = Modifier.weight(1f).fillMaxHeight())
                        }
                        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            PlaylistCoverImage(uri = covers[2], modifier = Modifier.weight(1f).fillMaxHeight())
                            PlaylistCoverImage(uri = covers[3], modifier = Modifier.weight(1f).fillMaxHeight())
                        }
                    }
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun AlbumCard(name: String, artist: String, cover: Uri, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.85f)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (cover != Uri.EMPTY) {
                    AsyncImage(
                        model = cover,
                        contentDescription = "Cover art for album $name",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Album, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                    }
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(10.dp)
            ) {
                Text(
                    text = name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = artist,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.secondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun HomeScreenAlbumCard(name: String, artist: String, cover: Uri, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(130.dp)
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Card(
            modifier = Modifier
                .size(122.dp)
                .aspectRatio(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (cover != Uri.EMPTY) {
                    AsyncImage(
                        model = cover,
                        contentDescription = "Cover art for album $name",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Album,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(44.dp)
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = artist,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.secondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CastDialog(viewModel: AurisViewModel, onDismiss: () -> Unit) {
    val castingTvName by viewModel.castingTvName.collectAsState()
    val discoveredDevices by viewModel.discoveredDevices.collectAsState()
    val isSearching by viewModel.isSearchingDevices.collectAsState()
    var manualIp by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf<String?>(null) }
    
    LaunchedEffect(Unit) {
        viewModel.startDiscovery()
    }
    
    DisposableEffect(Unit) {
        onDispose {
            viewModel.stopDiscovery()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Cast,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Cast Audio & Lyrics",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Connect to Google TV or Chromecast on your Wi-Fi to display lyrics automatically.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            if (castingTvName != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CastConnected,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Connected to $castingTvName",
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Active Wi-Fi connection. Casting lyrics.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        Button(
                            onClick = {
                                viewModel.stopCasting()
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("Disconnect", fontSize = 12.sp)
                        }
                    }
                }
            } else {
                if (isSearching && discoveredDevices.isEmpty()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 24.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(36.dp),
                            strokeWidth = 3.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Scanning Wi-Fi for Google TV devices...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Ensure your TV is connected to the same network",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Available Wi-Fi Devices (${discoveredDevices.size})",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        TextButton(
                            onClick = { viewModel.startDiscovery() },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Rescan", fontSize = 12.sp)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    if (discoveredDevices.isEmpty()) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.1f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No TV devices detected automatically",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Make sure client isolation / AP isolation is turned off on your router, or try connecting manually below.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 240.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(discoveredDevices) { device ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.startCasting(device.name)
                                            onDismiss()
                                        },
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.Tv,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = device.name,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "IP: ${device.ipAddress} • Port: ${device.port}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                        Icon(
                                            Icons.Default.ChevronRight,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Connect Manually by IP Address",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = manualIp,
                                onValueChange = {
                                    manualIp = it
                                    showError = null
                                },
                                placeholder = { Text("e.g. 192.168.1.100", fontSize = 13.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp),
                                shape = RoundedCornerShape(12.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                                isError = showError != null
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    val trimmed = manualIp.trim()
                                    if (trimmed.matches(Regex("^([0-9]{1,3}\\.){3}[0-9]{1,3}$"))) {
                                        viewModel.startCasting("Google TV ($trimmed)")
                                        onDismiss()
                                    } else {
                                        showError = "Invalid IP Address format"
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.height(48.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp)
                            ) {
                                Text("Connect", fontSize = 13.sp)
                            }
                        }
                        
                        if (showError != null) {
                            Text(
                                text = showError!!,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrackItem(track: AudioTrack, isSelected: Boolean, isLiked: Boolean, onLikeClick: () -> Unit, onOptionsClick: () -> Unit, onClick: () -> Unit) {
    val bgColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else Color.Transparent
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(bgColor)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Art placeholder/image
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = track.albumArtUri,
                contentDescription = "Album Art",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Fallback icon if AsyncImage is empty or loading
            if (track.albumArtUri == Uri.EMPTY) { // Simplified fallback representation
                Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
            }
            if (isSelected) {
                Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)))
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            }
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                track.title,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                track.artist,
                color = MaterialTheme.colorScheme.secondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 14.sp
            )
        }
        
        Spacer(modifier = Modifier.width(8.dp))
        
        IconButton(onClick = onLikeClick, modifier = Modifier.size(32.dp)) {
            Icon(
                if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Like",
                tint = if (isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(20.dp)
            )
        }
        
        IconButton(onClick = onOptionsClick, modifier = Modifier.size(32.dp)) {
            Icon(
                Icons.Default.MoreVert,
                contentDescription = "Options",
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(8.dp))

        Text(
            formatTime(track.duration),
            color = MaterialTheme.colorScheme.secondary,
            fontSize = 12.sp
        )
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun FullPlayerScreen(track: AudioTrack, viewModel: AurisViewModel, onClose: () -> Unit, onOptionsClick: () -> Unit) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val isShuffleEnabled by viewModel.isShuffleEnabled.collectAsState()
    val isLoopEnabled by viewModel.isLoopEnabled.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val currentTimeMs by viewModel.currentTimeMs.collectAsState()
    val likedTracks by viewModel.likedTracks.collectAsState()
    val isLiked = likedTracks.contains(track.id)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showRewindFeedback by remember { mutableStateOf(false) }
    var showForwardFeedback by remember { mutableStateOf(false) }

    val castingTvName by viewModel.castingTvName.collectAsState()
    var showCastDialog by remember { mutableStateOf(false) }

    if (showCastDialog) {
        CastDialog(viewModel = viewModel, onDismiss = { showCastDialog = false })
    }

    val dominantColorInt by viewModel.dominantColor.collectAsState()
    val dominantColor = dominantColorInt?.let { Color(it) }
    val gradientColorsInt by viewModel.gradientColors.collectAsState()
    val gradientColors = remember(gradientColorsInt) { gradientColorsInt.map { Color(it) } }

    Box(modifier = Modifier.fillMaxSize()) {
        AurisGradientBackground(dominantColor = dominantColor, gradientColors = gradientColors)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
        // Top Bar: Close button, Title, and Cast + More
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Close", tint = MaterialTheme.colorScheme.onBackground)
            }
            Text(
                "Now Playing",
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                color = MaterialTheme.colorScheme.secondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            IconButton(onClick = { showCastDialog = true }) {
                Icon(
                    imageVector = if (castingTvName != null) Icons.Default.CastConnected else Icons.Default.Cast,
                    contentDescription = "Cast",
                    tint = if (castingTvName != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
                )
            }
            IconButton(onClick = onOptionsClick) {
                Icon(Icons.Default.MoreVert, contentDescription = "More", tint = MaterialTheme.colorScheme.onBackground)
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))

        // Casting Status Pill
        if (castingTvName != null) {
            Row(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .background(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CastConnected,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Casting to $castingTvName",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        } else {
            Spacer(modifier = Modifier.height(8.dp))
        }
        
        // Album Art
        AnimatedContent(targetState = track, transitionSpec = {
            fadeIn(animationSpec = tween(500)) togetherWith fadeOut(animationSpec = tween(500))
        }, label = "AlbumArt") { targetTrack ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(32.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = { offset ->
                                val halfWidth = size.width / 2
                                if (offset.x < halfWidth) {
                                    viewModel.seekToMs(currentTimeMs - 5000L)
                                    showRewindFeedback = true
                                    scope.launch {
                                        delay(500)
                                        showRewindFeedback = false
                                    }
                                } else {
                                    viewModel.seekToMs(currentTimeMs + 5000L)
                                    showForwardFeedback = true
                                    scope.launch {
                                        delay(500)
                                        showForwardFeedback = false
                                    }
                                }
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = targetTrack.albumArtUri,
                    contentDescription = "Album Art",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                if (targetTrack.albumArtUri == Uri.EMPTY) {
                    Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(120.dp))
                }
                
                // Feedback overlay for double click rewind/forward
                if (showRewindFeedback) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(0.5f)
                            .align(Alignment.CenterStart)
                            .background(Color.Black.copy(alpha = 0.4f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.FastRewind,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("-5s", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (showForwardFeedback) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(0.5f)
                            .align(Alignment.CenterEnd)
                            .background(Color.Black.copy(alpha = 0.4f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.FastForward,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("+5s", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))

        // Title and Artist
        AnimatedContent(targetState = track, transitionSpec = {
            fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
        }, label = "Title") { targetTrack ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = targetTrack.title,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = targetTrack.artist,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { viewModel.toggleLike(targetTrack.id) }) {
                    Icon(
                        imageVector = if (likedTracks.contains(targetTrack.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (likedTracks.contains(targetTrack.id)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Progress Bar
        Slider(
            value = progress,
            onValueChange = { viewModel.seekTo(it) },
            modifier = Modifier.fillMaxWidth(),
             colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatTime(currentTimeMs), fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
            Text(formatTime(track.duration), fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
        }

        Spacer(modifier = Modifier.weight(1f))

        // Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.toggleShuffle() }) {
                Icon(
                    Icons.Default.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (isShuffleEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(24.dp)
                )
            }

            IconButton(onClick = { viewModel.playPrev(context) }) {
                Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
            }

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .clickable { viewModel.togglePlayPause() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(40.dp)
                )
            }

            IconButton(onClick = { viewModel.playNext(context) }) {
                Icon(Icons.Default.SkipNext, contentDescription = "Next", modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
            }

            IconButton(onClick = { viewModel.toggleLoop() }) {
                Icon(
                    Icons.Default.Repeat,
                    contentDescription = "Repeat",
                    tint = if (isLoopEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            var showQueueSheet by remember { mutableStateOf(false) }
            var showLyricsSheet by remember { mutableStateOf(false) }
            
            val launcher = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri: Uri? ->
                if (uri != null) {
                    try {
                        context.contentResolver.openInputStream(uri)?.use { stream ->
                            val content = stream.bufferedReader().readText()
                            viewModel.saveLyricsForCurrentTrack(content)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            IconButton(onClick = { showQueueSheet = true }) {
                Icon(
                    Icons.Default.QueueMusic,
                    contentDescription = "Queue",
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(28.dp)
                )
            }
            
            IconButton(onClick = { showLyricsSheet = true }) {
                Icon(
                    Icons.Default.Subject,
                    contentDescription = "Lyrics",
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(28.dp)
                )
            }

            if (showLyricsSheet) {
                val currentLyrics by viewModel.currentLyrics.collectAsState()
                val isFetchingLyrics by viewModel.isFetchingLyrics.collectAsState()
                val lyricsSource by viewModel.lyricsSource.collectAsState()

                ModalBottomSheet(onDismissRequest = { showLyricsSheet = false }) {
                    Column(modifier = Modifier.fillMaxSize().padding(bottom = 32.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Lyrics", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                if (lyricsSource.isNotEmpty()) {
                                    Text(
                                        text = lyricsSource,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val currentTrack by viewModel.currentTrack.collectAsState()
                                TextButton(
                                    onClick = { currentTrack?.let { viewModel.fetchLyricsAutomatically(it) } },
                                    enabled = !isFetchingLyrics
                                ) {
                                    Text("Refetch")
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                TextButton(onClick = { launcher.launch(arrayOf("*/*")) }) {
                                    Text("Import .lrc")
                                }
                            }
                        }
                        
                        if (isFetchingLyrics) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = lyricsSource.ifEmpty { "Searching multiple libraries..." },
                                        color = MaterialTheme.colorScheme.secondary,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        } else if (currentLyrics.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "No lyrics found.\nImport a .lrc file or search online.",
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(onClick = {
                                        val currentTrack = viewModel.currentTrack.value
                                        if (currentTrack != null) {
                                            viewModel.fetchLyricsAutomatically(currentTrack)
                                        }
                                    }) {
                                        Text("Search Libraries")
                                    }
                                }
                            }
                        } else {
                            val listState = androidx.compose.foundation.lazy.rememberLazyListState()
                            val density = androidx.compose.ui.platform.LocalDensity.current
                            val centerOffset = with(density) { 200.dp.roundToPx() }
                            
                            val activeIndex = currentLyrics.indexOfLast { it.timeMs <= currentTimeMs }
                            
                            LaunchedEffect(activeIndex) {
                                if (activeIndex >= 0 && !listState.isScrollInProgress) {
                                    listState.animateScrollToItem(activeIndex, scrollOffset = -centerOffset)
                                }
                            }
                            
                            LazyColumn(
                                state = listState, 
                                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                                contentPadding = PaddingValues(vertical = 160.dp)
                            ) {
                                itemsIndexed(currentLyrics) { index, line ->
                                    val isActive = index == activeIndex
                                    Text(
                                        text = line.text,
                                        fontSize = if (isActive) 22.sp else 18.sp,
                                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                                        modifier = Modifier.padding(vertical = 8.dp).fillMaxWidth().clickable { viewModel.seekToMs(line.timeMs) },
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (showQueueSheet) {
                val playbackQueue by viewModel.playbackQueue.collectAsState()
                ModalBottomSheet(onDismissRequest = { showQueueSheet = false }) {
                    Column(modifier = Modifier.fillMaxSize().padding(bottom = 32.dp)) {
                        Text(
                            "Playing Next", 
                            fontWeight = FontWeight.Bold, 
                            fontSize = 20.sp, 
                            modifier = Modifier.padding(16.dp)
                        )
                        if (playbackQueue.isEmpty()) {
                            Text(
                                "Queue is empty.",
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.padding(16.dp)
                            )
                        } else {
                            LazyColumn {
                                items(playbackQueue) { qTrack ->
                                    TrackItem(
                                        track = qTrack,
                                        isSelected = qTrack.id == track.id,
                                        isLiked = likedTracks.contains(qTrack.id),
                                        onLikeClick = { viewModel.toggleLike(qTrack.id) },
                                        onOptionsClick = { viewModel.removeFromQueue(qTrack) },
                                        onClick = { 
                                            viewModel.playTrackFromContext(qTrack, playbackQueue, context)
                                            showQueueSheet = false 
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(32.dp))
    }
    }
}

@Composable
fun BottomPlayerPanel(
    track: AudioTrack,
    viewModel: AurisViewModel,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val context = LocalContext.current

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f),
        contentColor = MaterialTheme.colorScheme.onSurface,
        shape = CircleShape, // Capsule shape
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        ), // Distinct contrasting border
        shadowElevation = 8.dp, // Higher shadow elevation for better floating contrast
        modifier = modifier
            .padding(vertical = 6.dp)
            .clickable { onClick() }
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 8.dp, end = 16.dp, top = 6.dp, bottom = 6.dp)
            ) {
                // Art
                AsyncImage(
                    model = track.albumArtUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        track.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        track.artist,
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = { viewModel.playPrev(context) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        Icons.Default.SkipPrevious, 
                        contentDescription = "Previous",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                
                Spacer(modifier = Modifier.width(4.dp))
                
                // Play/Pause button - dynamically colored per song cover art
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .clickable { viewModel.togglePlayPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                
                Spacer(modifier = Modifier.width(4.dp))

                IconButton(
                    onClick = { viewModel.playNext(context) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        Icons.Default.SkipNext, 
                        contentDescription = "Next",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            
            // Thin elegant progress line at the bottom
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .padding(horizontal = 24.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
            )
            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
fun CustomSectionBar(
    selectedTabIndex: Int,
    onTabSelected: (Int) -> Unit,
    tabs: List<String>,
    tabIcons: List<androidx.compose.ui.graphics.vector.ImageVector>,
    tabIconsSelected: List<androidx.compose.ui.graphics.vector.ImageVector>,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.45f),
        tonalElevation = 0.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEachIndexed { index, title ->
                val isSelected = selectedTabIndex == index
                val icon = if (isSelected) tabIconsSelected[index] else tabIcons[index]
                
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = null
                        ) {
                            onTabSelected(index)
                        }
                        .padding(vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(
                                color = if (isSelected) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    Color.Transparent
                                },
                                shape = RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = if (isSelected) {
                                MaterialTheme.colorScheme.onPrimaryContainer
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            },
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    
                    AnimatedVisibility(
                        visible = isSelected,
                        enter = fadeIn() + androidx.compose.animation.expandVertically(),
                        exit = fadeOut() + androidx.compose.animation.shrinkVertically()
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    filteredTracks: List<AudioTrack>,
    playHistory: List<AudioTrack>,
    playlists: Map<String, List<Long>>,
    onTrackClick: (AudioTrack, List<AudioTrack>) -> Unit,
    onPlaylistClick: (String) -> Unit,
    onAlbumClick: (String) -> Unit,
    onNavigateToTab: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val recentlyPlayed = playHistory.filter { filteredTracks.contains(it) }.take(8)
    val newTracks = filteredTracks.sortedByDescending { it.id }.take(6)
    val playlistNames = playlists.keys.toList()
    val albumNames = filteredTracks.map { it.album }.distinct().sorted()

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 120.dp, top = 8.dp)
    ) {
        // 1. Recently Played Section
        item {
            Column(modifier = Modifier.padding(bottom = 16.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.History,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Recently Played",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    if (recentlyPlayed.isNotEmpty()) {
                        TextButton(onClick = { onNavigateToTab(6) }) {
                            Text("See All", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                
                if (recentlyPlayed.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp)
                            .height(100.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Your play history will appear here.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(recentlyPlayed) { track ->
                            HomeScreenSongCard(
                                track = track,
                                onClick = { onTrackClick(track, recentlyPlayed) }
                            )
                        }
                    }
                }
            }
        }

        // 2. New Added Songs Section
        item {
            Column(modifier = Modifier.padding(bottom = 12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.NewReleases,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "New Added Songs",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                
                if (newTracks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp)
                            .height(100.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No local music tracks found.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
        }

        if (newTracks.isNotEmpty()) {
            val chunkedNewTracks = newTracks.chunked(2)
            items(chunkedNewTracks) { pair ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    pair.forEach { track ->
                        Box(modifier = Modifier.weight(1f)) {
                            HomeScreenSongGridCard(
                                track = track,
                                onClick = { onTrackClick(track, filteredTracks) }
                            )
                        }
                    }
                    if (pair.size < 2) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // 3. Albums Section
        item {
            Column(modifier = Modifier.padding(top = 16.dp, bottom = 12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Album,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Albums",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    if (albumNames.isNotEmpty()) {
                        TextButton(onClick = { onNavigateToTab(2) }) {
                            Text("See All", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                
                if (albumNames.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp)
                            .height(100.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No albums found.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(albumNames.take(8)) { albumName ->
                            val albumTracks = filteredTracks.filter { it.album == albumName }
                            val firstTrack = albumTracks.firstOrNull()
                            val cover = firstTrack?.albumArtUri ?: Uri.EMPTY
                            val artist = firstTrack?.artist ?: "Unknown Artist"
                            HomeScreenAlbumCard(
                                name = albumName,
                                artist = artist,
                                cover = cover,
                                onClick = { onAlbumClick(albumName) }
                            )
                        }
                    }
                }
            }
        }

        // 4. Playlists Section
        item {
            Column(modifier = Modifier.padding(top = 16.dp, bottom = 12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.PlaylistPlay,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Playlists",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    if (playlistNames.isNotEmpty()) {
                        TextButton(onClick = { onNavigateToTab(4) }) {
                            Text("See All", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                
                if (playlistNames.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp)
                            .height(100.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No playlists created yet.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
        }

        if (playlistNames.isNotEmpty()) {
            val displayedPlaylists = playlistNames.take(4)
            val chunkedPlaylists = displayedPlaylists.chunked(2)
            items(chunkedPlaylists) { pair ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    pair.forEach { pl ->
                        val trackIds = playlists[pl] ?: emptyList()
                        val covers = trackIds.mapNotNull { id -> filteredTracks.find { it.id == id }?.albumArtUri }.take(4)
                        Box(modifier = Modifier.weight(1f)) {
                            PlaylistCard(name = pl, covers = covers, onClick = { onPlaylistClick(pl) })
                        }
                    }
                    if (pair.size < 2) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreenSongCard(track: AudioTrack, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(130.dp)
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Card(
            modifier = Modifier
                .size(122.dp)
                .aspectRatio(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (track.albumArtUri != Uri.EMPTY) {
                    AsyncImage(
                        model = track.albumArtUri,
                        contentDescription = "Cover art for ${track.title}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(44.dp)
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = track.title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = track.artist,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.secondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun HomeScreenSongGridCard(track: AudioTrack, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Card(
                modifier = Modifier.size(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    if (track.albumArtUri != Uri.EMPTY) {
                        AsyncImage(
                            model = track.albumArtUri,
                            contentDescription = "Cover art for ${track.title}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = track.artist,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.secondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

