package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils

private val AurisColorScheme =
  darkColorScheme(
    primary = AurisPrimary,
    secondary = AurisSecondary,
    tertiary = AurisAccent,
    background = Color.Transparent,
    surface = AurisSurface.copy(alpha = 0.5f),
    surfaceVariant = AurisSurfaceVariant.copy(alpha = 0.6f),
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    onSurfaceVariant = Color(0xFFCCCCCC)
  )
@Composable
fun MyApplicationTheme(
  dynamicColor: Color? = null,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (dynamicColor != null) {
      val isLight = ColorUtils.calculateLuminance(dynamicColor.toArgb()) > 0.5
      val primary = if (isLight) dynamicColor else Color(ColorUtils.blendARGB(dynamicColor.toArgb(), Color.White.toArgb(), 0.5f))
      val bg = Color.Transparent
      val surface = Color(ColorUtils.blendARGB(AurisSurface.toArgb(), dynamicColor.toArgb(), 0.15f)).copy(alpha = 0.5f)
      val surfaceVariant = Color(ColorUtils.blendARGB(AurisSurfaceVariant.toArgb(), dynamicColor.toArgb(), 0.2f)).copy(alpha = 0.6f)
      
      AurisColorScheme.copy(
          primary = primary,
          background = bg,
          surface = surface,
          surfaceVariant = surfaceVariant
      )
  } else {
      AurisColorScheme
  }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
