package com.example

import android.content.Context
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import kotlin.concurrent.thread

class LocalHttpServer(
    private val context: Context,
    private val port: Int = 8085,
    private val getAudioUri: (Long) -> Uri?,
    private val getLyricsContent: (Long) -> String?,
    private val getAlbumArtUri: ((Long) -> Uri?)? = null,
    private val getCurrentState: (() -> String?)? = null
) {
    private var serverSocket: ServerSocket? = null
    private var isRunning = false
    private val sseConnections = Collections.synchronizedList(mutableListOf<Socket>())

    fun start() {
        if (isRunning) return
        isRunning = true
        thread(start = true, name = "LocalHttpServerThread") {
            try {
                serverSocket = ServerSocket(port)
                while (isRunning) {
                    val socket = serverSocket?.accept() ?: break
                    thread { handleClient(socket) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun stop() {
        isRunning = false
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        serverSocket = null
        
        synchronized(sseConnections) {
            for (socket in sseConnections) {
                try { socket.close() } catch (e: Exception) {}
            }
            sseConnections.clear()
        }
    }

    fun broadcastState(stateJson: String) {
        broadcastEvent("state", stateJson)
    }

    private fun broadcastEvent(event: String, data: String) {
        val payload = "event: $event\ndata: $data\n\n"
        val bytes = payload.toByteArray(Charsets.UTF_8)
        synchronized(sseConnections) {
            val iterator = sseConnections.iterator()
            while (iterator.hasNext()) {
                val socket = iterator.next()
                try {
                    val out = socket.getOutputStream()
                    out.write(bytes)
                    out.flush()
                } catch (e: Exception) {
                    try { socket.close() } catch (ex: Exception) {}
                    iterator.remove()
                }
            }
        }
    }

    private fun handleClient(socket: Socket) {
        var preventAutoClose = false
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val line = reader.readLine() ?: return
            val parts = line.split(" ")
            if (parts.size < 2 || parts[0] != "GET") {
                send400(socket)
                return
            }
            val uriPath = parts[1]
            if (uriPath.startsWith("/audio")) {
                val id = extractQueryParam(uriPath, "id")?.toLongOrNull()
                if (id != null) {
                    serveAudio(socket, id)
                } else {
                    send404(socket)
                }
            } else if (uriPath.startsWith("/lyrics_lrc")) {
                val id = extractQueryParam(uriPath, "id")?.toLongOrNull()
                if (id != null) {
                    serveRawLyrics(socket, id)
                } else {
                    send404(socket)
                }
            } else if (uriPath.startsWith("/lyrics")) {
                val id = extractQueryParam(uriPath, "id")?.toLongOrNull()
                if (id != null) {
                    serveLyrics(socket, id)
                } else {
                    send404(socket)
                }
            } else if (uriPath.startsWith("/album_art")) {
                val id = extractQueryParam(uriPath, "id")?.toLongOrNull()
                if (id != null) {
                    serveAlbumArt(socket, id)
                } else {
                    send404(socket)
                }
            } else if (uriPath == "/tv" || uriPath.startsWith("/tv?")) {
                serveTvPage(socket)
            } else if (uriPath.startsWith("/events")) {
                preventAutoClose = true
                handleEvents(socket)
            } else {
                send404(socket)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (!preventAutoClose) {
                try {
                    socket.close()
                } catch (e: Exception) {
                    // Ignore
                }
            }
        }
    }

    private fun extractQueryParam(path: String, name: String): String? {
        val query = path.substringAfter("?", "")
        if (query.isEmpty()) return null
        val params = query.split("&")
        for (p in params) {
            val kv = p.split("=")
            if (kv.size == 2 && kv[0] == name) {
                return kv[1]
            }
        }
        return null
    }

    private fun serveAudio(socket: Socket, id: Long) {
        val audioUri = getAudioUri(id) ?: run {
            send404(socket)
            return
        }
        try {
            val inputStream = context.contentResolver.openInputStream(audioUri) ?: run {
                send404(socket)
                return
            }
            val out = socket.getOutputStream()
            val totalBytes = inputStream.available()
            
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: audio/mpeg\r\n" +
                    "Content-Length: $totalBytes\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Connection: close\r\n\r\n"
            out.write(header.toByteArray())
            
            val buffer = ByteArray(8192)
            var read: Int
            while (inputStream.read(buffer).also { read = it } != -1) {
                out.write(buffer, 0, read)
            }
            out.flush()
            inputStream.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun serveRawLyrics(socket: Socket, id: Long) {
        val lrcContent = getLyricsContent(id) ?: ""
        try {
            val out = socket.getOutputStream()
            val bytes = lrcContent.toByteArray(Charsets.UTF_8)
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: text/plain; charset=utf-8\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Connection: close\r\n\r\n"
            out.write(header.toByteArray())
            out.write(bytes)
            out.flush()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun serveLyrics(socket: Socket, id: Long) {
        val lrcContent = getLyricsContent(id) ?: ""
        val webVtt = lrcToWebVtt(lrcContent)
        try {
            val out = socket.getOutputStream()
            val bytes = webVtt.toByteArray(Charsets.UTF_8)
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: text/vtt; charset=utf-8\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Connection: close\r\n\r\n"
            out.write(header.toByteArray())
            out.write(bytes)
            out.flush()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun serveAlbumArt(socket: Socket, id: Long) {
        val albumArtUri = getAlbumArtUri?.invoke(id)
        if (albumArtUri == null || albumArtUri == Uri.EMPTY) {
            send404(socket)
            return
        }
        try {
            val inputStream = context.contentResolver.openInputStream(albumArtUri) ?: run {
                send404(socket)
                return
            }
            val out = socket.getOutputStream()
            val totalBytes = inputStream.available()
            
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: image/jpeg\r\n" +
                    "Content-Length: $totalBytes\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Connection: close\r\n\r\n"
            out.write(header.toByteArray())
            
            val buffer = ByteArray(8192)
            var read: Int
            while (inputStream.read(buffer).also { read = it } != -1) {
                out.write(buffer, 0, read)
            }
            out.flush()
            inputStream.close()
        } catch (e: Exception) {
            e.printStackTrace()
            send404(socket)
        }
    }

    private fun serveTvPage(socket: Socket) {
        val html = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Auris TV Cast Receiver</title>
                <style>
                    body, html {
                        margin: 0; padding: 0;
                        width: 100%; height: 100%;
                        overflow: hidden;
                        background-color: #000;
                        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                        color: #fff;
                    }

                    #bg-img {
                        position: fixed;
                        top: -10%; left: -10%; width: 120%; height: 120%;
                        filter: blur(80px) brightness(0.3) saturate(1.5);
                        z-index: -1;
                        object-fit: cover;
                        transition: opacity 1s ease-in-out;
                        opacity: 0.8;
                    }

                    .container {
                        display: flex;
                        width: 100%; height: 100%;
                        box-sizing: border-box;
                        background: radial-gradient(circle at center, rgba(0,0,0,0.05) 0%, rgba(0,0,0,0.75) 100%);
                    }

                    .lyrics-pane {
                        flex: 1.25;
                        height: 100%;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                        padding: 0 64px;
                        box-sizing: border-box;
                        position: relative;
                    }

                    .lyrics-container {
                        height: 70%;
                        overflow: hidden;
                        position: relative;
                        mask-image: linear-gradient(to bottom, transparent 0%, white 20%, white 80%, transparent 100%);
                        -webkit-mask-image: linear-gradient(to bottom, transparent 0%, white 20%, white 80%, transparent 100%);
                    }

                    .lyrics-scroll {
                        position: absolute;
                        width: 100%;
                        transition: transform 0.6s cubic-bezier(0.25, 1, 0.5, 1);
                        top: 40%;
                    }

                    .lyric-line {
                        font-size: 34px;
                        font-weight: 600;
                        line-height: 1.6;
                        margin-bottom: 32px;
                        color: rgba(255,255,255,0.3);
                        transition: all 0.5s ease;
                        transform-origin: left center;
                    }

                    .lyric-line.active {
                        color: #ffffff;
                        font-size: 46px;
                        font-weight: 800;
                        text-shadow: 0 4px 20px rgba(0,0,0,0.6);
                        transform: scale(1.04);
                    }

                    .no-lyrics {
                        font-size: 28px;
                        color: rgba(255,255,255,0.5);
                        text-align: left;
                        padding-left: 24px;
                    }

                    .info-pane {
                        flex: 0.75;
                        height: 100%;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                        align-items: center;
                        padding: 48px;
                        box-sizing: border-box;
                        border-left: 1px solid rgba(255,255,255,0.08);
                        background: rgba(0,0,0,0.3);
                        backdrop-filter: blur(25px);
                    }

                    .art-container {
                        width: 340px; height: 340px;
                        border-radius: 28px;
                        overflow: hidden;
                        box-shadow: 0 25px 55px rgba(0,0,0,0.85);
                        margin-bottom: 40px;
                        background: #222;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }

                    .art-container img {
                        width: 100%; height: 100%;
                        object-fit: cover;
                    }

                    .song-details {
                        text-align: center;
                        width: 100%;
                        max-width: 400px;
                    }

                    .song-title {
                        font-size: 32px;
                        font-weight: 800;
                        margin: 0;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        text-shadow: 0 2px 4px rgba(0,0,0,0.4);
                    }

                    .song-artist {
                        font-size: 22px;
                        font-weight: 500;
                        color: rgba(255,255,255,0.65);
                        margin: 12px 0 0 0;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }

                    .progress-container {
                        width: 100%;
                        max-width: 400px;
                        margin-top: 40px;
                        display: flex;
                        align-items: center;
                        gap: 12px;
                    }

                    .time-label {
                        font-size: 14px;
                        color: rgba(255,255,255,0.5);
                        font-family: monospace;
                        width: 45px;
                    }

                    .progress-bar-bg {
                        flex: 1;
                        height: 6px;
                        background: rgba(255,255,255,0.15);
                        border-radius: 3px;
                        overflow: hidden;
                        position: relative;
                    }

                    .progress-bar-fill {
                        height: 100%;
                        width: 0%;
                        background: #fff;
                        border-radius: 3px;
                        transition: width 0.1s linear;
                    }
                </style>
            </head>
            <body>
                <img id="bg-img" src="" alt="">
                <div class="container">
                    <div class="lyrics-pane">
                        <div class="lyrics-container">
                            <div id="lyrics-scroll" class="lyrics-scroll">
                                <div class="no-lyrics">Auris is ready to cast. Play a track to begin!</div>
                            </div>
                        </div>
                    </div>

                    <div class="info-pane">
                        <div class="art-container" id="art-container">
                            <img id="album-art" src="" alt="" style="display:none;">
                            <svg id="art-placeholder" viewBox="0 0 24 24" width="96" height="96" fill="rgba(255,255,255,0.2)">
                                <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
                            </svg>
                        </div>
                        <div class="song-details">
                            <h1 id="song-title" class="song-title">Auris</h1>
                            <h2 id="song-artist" class="song-artist">No Track Playing</h2>
                        </div>
                        <div class="progress-container">
                            <span id="time-current" class="time-label">0:00</span>
                            <div class="progress-bar-bg">
                                <div id="progress-fill" class="progress-bar-fill"></div>
                            </div>
                            <span id="time-total" class="time-label">0:00</span>
                        </div>
                    </div>
                </div>

                <audio id="audio-player"></audio>

                <script>
                    const audio = document.getElementById('audio-player');
                    const bgImg = document.getElementById('bg-img');
                    const albumArt = document.getElementById('album-art');
                    const artPlaceholder = document.getElementById('art-placeholder');
                    const songTitle = document.getElementById('song-title');
                    const songArtist = document.getElementById('song-artist');
                    const timeCurrent = document.getElementById('time-current');
                    const timeTotal = document.getElementById('time-total');
                    const progressFill = document.getElementById('progress-fill');
                    const lyricsScroll = document.getElementById('lyrics-scroll');

                    let lyrics = [];
                    let activeIndex = -1;
                    let currentTrackId = null;

                    const es = new EventSource('/events');

                    es.addEventListener('handshake', (e) => {
                        console.log("SSE connected!");
                    });

                    es.addEventListener('state', (e) => {
                        const state = JSON.parse(e.data);
                        updateState(state);
                    });

                    function formatTime(ms) {
                        if (isNaN(ms) || ms < 0) return '0:00';
                        const totalSecs = Math.floor(ms / 1000);
                        const mins = Math.floor(totalSecs / 60);
                        const secs = totalSecs % 60;
                        return mins + ':' + (secs < 10 ? '0' : '') + secs;
                    }

                    function updateState(state) {
                        const trackChanged = currentTrackId !== state.trackId;
                        currentTrackId = state.trackId;

                        songTitle.innerText = state.title;
                        songArtist.innerText = state.artist;

                        if (state.albumArtUri && state.albumArtUri !== 'android.resource://com.example/0' && state.albumArtUri !== '') {
                            const artUrl = '/album_art?id=' + state.trackId;
                            bgImg.src = artUrl;
                            albumArt.src = artUrl;
                            albumArt.style.display = 'block';
                            artPlaceholder.style.display = 'none';
                        } else {
                            bgImg.src = '';
                            albumArt.style.display = 'none';
                            artPlaceholder.style.display = 'block';
                        }

                        if (trackChanged) {
                            audio.src = '/audio?id=' + state.trackId;
                            loadLyrics(state.trackId);
                        }

                        const targetSec = state.positionMs / 1000;
                        const diff = Math.abs(audio.currentTime - targetSec);
                        if (diff > 1.2 || trackChanged) {
                            audio.currentTime = targetSec;
                        }

                        if (state.isPlaying) {
                            if (audio.paused) {
                                audio.play().catch(err => console.log("Audio play failed: ", err));
                            }
                        } else {
                            if (!audio.paused) {
                                audio.pause();
                            }
                        }

                        updateProgressAndLyrics(Math.floor(audio.currentTime * 1000), state.durationMs);
                    }

                    function updateProgressAndLyrics(currMs, durMs) {
                        if (currMs > durMs) currMs = durMs;
                        timeCurrent.innerText = formatTime(currMs);
                        timeTotal.innerText = formatTime(durMs);
                        const percent = durMs > 0 ? (currMs / durMs) * 100 : 0;
                        progressFill.style.width = percent + '%';
                        highlightLyrics(currMs);
                    }

                    audio.addEventListener('timeupdate', () => {
                        const currMs = Math.floor(audio.currentTime * 1000);
                        const durMs = Math.floor(audio.duration * 1000) || 0;
                        if (durMs > 0) {
                            updateProgressAndLyrics(currMs, durMs);
                        }
                    });

                    function loadLyrics(trackId) {
                        lyricsScroll.innerHTML = '<div class="no-lyrics">Loading lyrics...</div>';
                        lyrics = [];
                        activeIndex = -1;

                        fetch('/lyrics_lrc?id=' + trackId)
                            .then(r => r.text())
                            .then(text => {
                                if (!text || text.trim() === "") {
                                    lyricsScroll.innerHTML = '<div class="no-lyrics">Lyrics not available for this track</div>';
                                    return;
                                }
                                parseLrc(text);
                            })
                            .catch(err => {
                                lyricsScroll.innerHTML = '<div class="no-lyrics">Enjoy the music!</div>';
                            });
                    }

                    function parseLrc(content) {
                        const lines = content.split('\n');
                        lyrics = [];
                        const regex = /\[(\d{2,}):(\d{2})\.(\d{2,3})\](.*)/;
                        
                        lines.forEach(line => {
                            const match = regex.exec(line.trim());
                            if (match) {
                                const min = parseInt(match[1]);
                                const sec = parseInt(match[2]);
                                const msStr = match[3];
                                const ms = parseInt(msStr) * (msStr.length === 2 ? 10 : 1);
                                const text = match[4].trim();
                                const timeMs = (min * 60 + sec) * 1000 + ms;
                                lyrics.push({ timeMs, text });
                            }
                        });

                        lyrics.sort((a, b) => a.timeMs - b.timeMs);

                        if (lyrics.length === 0) {
                            lyricsScroll.innerHTML = '<div class="no-lyrics">Enjoy the music!</div>';
                            return;
                        }

                        lyricsScroll.innerHTML = '';
                        lyrics.forEach((line, index) => {
                            const div = document.createElement('div');
                            div.className = 'lyric-line';
                            div.id = 'line-' + index;
                            div.innerText = line.text;
                            lyricsScroll.appendChild(div);
                        });
                    }

                    function highlightLyrics(timeMs) {
                        if (lyrics.length === 0) return;

                        let index = -1;
                        for (let i = 0; i < lyrics.length; i++) {
                            if (lyrics[i].timeMs <= timeMs) {
                                index = i;
                            } else {
                                break;
                            }
                        }

                        if (index !== activeIndex) {
                            if (activeIndex >= 0) {
                                const prev = document.getElementById('line-' + activeIndex);
                                if (prev) prev.classList.remove('active');
                            }
                            activeIndex = index;
                            if (activeIndex >= 0) {
                                const curr = document.getElementById('line-' + activeIndex);
                                if (curr) {
                                    curr.classList.add('active');
                                    const offset = curr.offsetTop - (lyricsScroll.parentElement.offsetHeight / 2) + (curr.offsetHeight / 2);
                                    lyricsScroll.style.transform = 'translateY(-' + offset + 'px)';
                                }
                            } else {
                                lyricsScroll.style.transform = `translateY(0px)`;
                            }
                        }
                    }
                </script>
            </body>
            </html>
        """.trimIndent()

        try {
            val out = socket.getOutputStream()
            val bytes = html.toByteArray(Charsets.UTF_8)
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: text/html; charset=utf-8\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Connection: close\r\n\r\n"
            out.write(header.toByteArray())
            out.write(bytes)
            out.flush()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handleEvents(socket: Socket) {
        try {
            val out = socket.getOutputStream()
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: text/event-stream\r\n" +
                    "Cache-Control: no-cache\r\n" +
                    "Connection: keep-alive\r\n" +
                    "Access-Control-Allow-Origin: *\r\n\r\n"
            out.write(header.toByteArray())
            out.flush()

            sseConnections.add(socket)

            out.write("event: handshake\ndata: connected\n\n".toByteArray())
            out.flush()

            val initialState = getCurrentState?.invoke()
            if (initialState != null) {
                out.write("event: state\ndata: $initialState\n\n".toByteArray())
                out.flush()
            }

            val input = socket.getInputStream()
            val buffer = ByteArray(1024)
            while (socket.isConnected && !socket.isClosed) {
                val read = input.read(buffer)
                if (read == -1) break
            }
        } catch (e: Exception) {
            // Ignore
        } finally {
            sseConnections.remove(socket)
            try { socket.close() } catch (e: Exception) {}
        }
    }

    private fun lrcToWebVtt(lrc: String): String {
        if (lrc.isEmpty()) return "WEBVTT\n\n00:00.000 --> 99:59.999\nEnjoy the music"
        val lines = lrc.split("\n")
        val sb = StringBuilder()
        sb.append("WEBVTT\n\n")
        
        val parsedLines = mutableListOf<Pair<Long, String>>()
        val regex = Regex("\\[(\\d{2,}):(\\d{2})\\.(\\d{2,3})\\](.*)")
        for (line in lines) {
            val match = regex.find(line.trim())
            if (match != null) {
                val min = match.groupValues[1].toLong()
                val sec = match.groupValues[2].toLong()
                val msStr = match.groupValues[3]
                val ms = msStr.toLong() * (if (msStr.length == 2) 10 else 1)
                val text = match.groupValues[4].trim()
                val timeMs = (min * 60 + sec) * 1000 + ms
                parsedLines.add(Pair(timeMs, text))
            }
        }
        
        parsedLines.sortBy { it.first }
        
        for (i in 0 until parsedLines.size) {
            val current = parsedLines[i]
            val nextTimeMs = if (i < parsedLines.size - 1) parsedLines[i + 1].first else current.first + 5000
            val startStr = formatMsToVttTime(current.first)
            val endStr = formatMsToVttTime(nextTimeMs)
            sb.append("${startStr} --> ${endStr}\n")
            sb.append("${current.second}\n\n")
        }
        return sb.toString()
    }

    private fun formatMsToVttTime(ms: Long): String {
        val min = ms / 60000
        val sec = (ms % 60000) / 1000
        val millis = ms % 1000
        return String.format("%02d:%02d.%03d", min, sec, millis)
    }

    private fun send404(socket: Socket) {
        try {
            val out = socket.getOutputStream()
            val body = "File Not Found"
            val header = "HTTP/1.1 404 Not Found\r\n" +
                    "Content-Type: text/plain\r\n" +
                    "Content-Length: ${body.length}\r\n" +
                    "Connection: close\r\n\r\n"
            out.write((header + body).toByteArray())
            out.flush()
        } catch (e: Exception) {}
    }

    private fun send400(socket: Socket) {
        try {
            val out = socket.getOutputStream()
            val body = "Bad Request"
            val header = "HTTP/1.1 400 Bad Request\r\n" +
                    "Content-Type: text/plain\r\n" +
                    "Content-Length: ${body.length}\r\n" +
                    "Connection: close\r\n\r\n"
            out.write((header + body).toByteArray())
            out.flush()
        } catch (e: Exception) {}
    }
}
