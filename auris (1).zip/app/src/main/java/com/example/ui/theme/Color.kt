package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AurisBackground = Color(0xFF0E0E0E)
val AurisSurface = Color(0xFF141414)
val AurisSurfaceVariant = Color(0xFF2A2A2A)
val AurisPrimary = Color(0xFFE0E0E0)
val AurisSecondary = Color(0xFFAAAAAA)
val AurisAccent = Color(0xFFFFFFFF)
val AurisGlow = Color(0x33FFFFFF)
